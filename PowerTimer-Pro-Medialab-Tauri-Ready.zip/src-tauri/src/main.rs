#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::process::Command;

#[tauri::command]
fn perform_action(action: String, force_kill: bool) -> Result<(), String> {
    #[cfg(target_os = "windows")]
    {
        match action.as_str() {
            "shutdown" => {
                let mut cmd = Command::new("shutdown.exe");
                cmd.args(["/s", "/t", "0"]);
                if force_kill { cmd.arg("/f"); }
                cmd.status().map_err(|e| e.to_string())?;
            }
            "restart" => {
                let mut cmd = Command::new("shutdown.exe");
                cmd.args(["/r", "/t", "0"]);
                if force_kill { cmd.arg("/f"); }
                cmd.status().map_err(|e| e.to_string())?;
            }
            "lock" => {
                Command::new("rundll32.exe")
                    .args(["user32.dll,LockWorkStation"])
                    .status()
                    .map_err(|e| e.to_string())?;
            }
            "sleep" => {
                Command::new("rundll32.exe")
                    .args(["powrprof.dll,SetSuspendState", "0,1,0"])
                    .status()
                    .map_err(|e| e.to_string())?;
            }
            _ => return Err(format!("Unknown action: {action}")),
        }
        Ok(())
    }

    #[cfg(not(target_os = "windows"))]
    {
        let _ = (action, force_kill);
        Err("This application is supported on Windows only.".into())
    }
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![perform_action])
        .run(tauri::generate_context!())
        .expect("error while running MediaLab Shutdown Timer");
}
