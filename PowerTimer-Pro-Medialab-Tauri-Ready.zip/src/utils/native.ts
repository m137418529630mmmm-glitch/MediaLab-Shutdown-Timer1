import { invoke } from "@tauri-apps/api/core";

export type NativeAction = "shutdown" | "restart" | "lock" | "sleep";

export async function executeNativeAction(action: NativeAction, forceKill: boolean): Promise<void> {
  await invoke("perform_action", { action, forceKill });
}
